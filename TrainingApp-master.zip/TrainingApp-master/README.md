# Training App (React)

A responsive Trainings website with image uploading features integrated with Firebase User Authentication and Firestore Database.

Features:

1. Log In with email and password
2. Enter training
3. Add a picture to your training
4. Edit your training
5. Delete training
6. Delete/reupload Image
