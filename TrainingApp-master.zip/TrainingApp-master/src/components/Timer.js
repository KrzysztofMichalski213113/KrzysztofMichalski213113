import React from "react"

export default function Timer() {
    return (
    <div>Timer</div>
    )
}