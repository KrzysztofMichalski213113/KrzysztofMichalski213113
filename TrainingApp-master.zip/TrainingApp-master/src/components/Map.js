import React from "react"

export default function MapComponent() {
    return (
    <div>Map</div>
    )
}