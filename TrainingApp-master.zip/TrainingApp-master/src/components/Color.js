const color1 = '#CEE5D0';
const color2 = "#F3F0D7";
const color3 = "#ebc89b";
const color4 = "#695c4c";

//default color that is used throughout the project
export {
    color1,
    color2,
    color3,
    color4
}